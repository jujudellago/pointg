<?php
	get_header();
		include(ENOVATHEMES_ADDONS.'event/content-event-header.php');
		include(ENOVATHEMES_ADDONS.'event/content-event-loop.php');
	get_footer(); 
?>