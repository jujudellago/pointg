<?php
	get_header();
		include(ENOVATHEMES_ADDONS.'menu/content-menu-header.php');
		include(ENOVATHEMES_ADDONS.'menu/content-menu-loop.php');
	get_footer(); 
?>